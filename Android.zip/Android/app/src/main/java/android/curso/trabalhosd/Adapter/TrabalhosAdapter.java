package android.curso.trabalhosd.Adapter;

import android.content.Context;
import android.curso.trabalhosd.Entidades.Trabalhos;
import android.curso.trabalhosd.R;
import android.icu.text.UnicodeSetSpanner;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class TrabalhosAdapter extends ArrayAdapter<Trabalhos> {
    private ArrayList<Trabalhos> trabalhos;
    private Context context;


    public TrabalhosAdapter(Context c, ArrayList<Trabalhos> objects) {
        super(c, 0, objects);

        this.context = c;
        this.trabalhos = objects;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view = null;

        if (trabalhos != null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);

            view = inflater.inflate(R.layout.lista_trabalhos, parent, false);

            TextView textViewNomeTrabalho =  view.findViewById(R.id.textViewNomeTrabalho);
            TextView textViewNomeAutor =  view.findViewById(R.id.textViewNomeAutor);
            TextView textViewLinguagem =  view.findViewById(R.id.textViewLinguagem);
            TextView textViewEnderecoGit =  view.findViewById(R.id.textViewEnderecoGit);
            TextView textViewUsuario =  view.findViewById(R.id.textViewUsuario);

            Trabalhos trabalhos2 = trabalhos.get(position);

            textViewNomeTrabalho.setText(trabalhos2.getNomeTrabalho());
            textViewNomeAutor.setText(trabalhos2.getNomeAutor());
            textViewLinguagem.setText(trabalhos2.getLinguagem());
            textViewEnderecoGit.setText(trabalhos2.getEnderecoGit());
            textViewUsuario.setText(trabalhos2.getUsuario());

        }


        return view;
    }
}
