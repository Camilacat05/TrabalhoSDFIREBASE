package android.curso.trabalhosd;

import android.content.Intent;
import android.curso.trabalhosd.DAO.ConfiguracaoFirebase;
import android.curso.trabalhosd.Entidades.Trabalhos;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;


public class AlterarActivity extends AppCompatActivity {
    private EditText AlterarNomeTrabalho;
    private EditText AlterarAutorTrabalho;
    private EditText AlterarLinguagemTrabalho;
    private EditText AlterarEnderecoGitTrabalho;
    private EditText AlterarUsuario;
    private EditText AlterarSenha;
    private Button btnAlterar;
    private Trabalhos trabalhos;
    private DatabaseReference firebase;
    private String user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alterar);

        btnAlterar = findViewById(R.id.btnAlterar);
        firebase = ConfiguracaoFirebase.getFirebase().child("Trabalhos");

        btnAlterar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlterarNomeTrabalho = findViewById(R.id.AlterarNomeTrabalho);
                AlterarAutorTrabalho = findViewById(R.id.AlterarAutorTrabalho);
                AlterarLinguagemTrabalho = findViewById(R.id.AlterarLinguagemTrabalho);
                AlterarEnderecoGitTrabalho = findViewById(R.id.AlterarEnderecoGitTrabalho);
                AlterarUsuario = findViewById(R.id.AlterarUsuario);
                AlterarSenha = findViewById(R.id.AlterarSenha);

                trabalhos = new Trabalhos();
                trabalhos.setNomeTrabalho(AlterarNomeTrabalho.getText().toString());
                trabalhos.setNomeAutor(AlterarAutorTrabalho.getText().toString());
                trabalhos.setLinguagem(AlterarLinguagemTrabalho.getText().toString());
                trabalhos.setEnderecoGit(AlterarEnderecoGitTrabalho.getText().toString());
                trabalhos.setUsuario(AlterarUsuario.getText().toString());
                trabalhos.setSenha(AlterarSenha.getText().toString());
                Intent intent = getIntent();
                if(intent != null){
                    Bundle b = intent.getExtras();
                    if (b != null){
                        String user = b.getString("user");
                        firebase.child(user).removeValue();
                        firebase = ConfiguracaoFirebase.getFirebase().child("Trabalhos");
                        firebase.child(trabalhos.getUsuario()).setValue(trabalhos);
                        Intent i = new Intent(getApplicationContext(),HomeActivity.class);
                        startActivity(i);
                    }
                }
            }
        });


    }

}
