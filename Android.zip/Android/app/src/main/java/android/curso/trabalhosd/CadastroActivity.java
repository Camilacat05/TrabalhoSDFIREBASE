package android.curso.trabalhosd;

import android.content.Intent;
import android.curso.trabalhosd.DAO.ConfiguracaoFirebase;
import android.curso.trabalhosd.Entidades.Trabalhos;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CadastroActivity extends AppCompatActivity {

    private EditText NomeTrabalho;
    private EditText AutorTrabalho;
    private EditText LinguagemTrabalho;
    private EditText EnderecoGitTrabalho;
    private EditText UsuarioTrabalho;
    private EditText SenhaTrabalho;
    private Button   btnCadastrar;
    private Button   btnListar;
    private Trabalhos trabalhos;
    private DatabaseReference firebase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        btnListar = findViewById(R.id.btnListar);
        btnCadastrar = findViewById(R.id.btnCadastrar);

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NomeTrabalho = findViewById(R.id.NomeTrabalho);
                AutorTrabalho = findViewById(R.id.AutorTrabalho);
                LinguagemTrabalho = findViewById(R.id.LinguagemTrabalho);
                EnderecoGitTrabalho = findViewById(R.id.EnderecoGitTrabalho);
                UsuarioTrabalho = findViewById(R.id.UsuárioTrabalho);
                SenhaTrabalho =  findViewById(R.id.SenhaTrabalho);

                trabalhos = new Trabalhos();

                trabalhos.setNomeTrabalho(NomeTrabalho.getText().toString());
                trabalhos.setNomeAutor(AutorTrabalho.getText().toString());
                trabalhos.setLinguagem(LinguagemTrabalho.getText().toString());
                trabalhos.setEnderecoGit(EnderecoGitTrabalho.getText().toString());
                trabalhos.setUsuario(UsuarioTrabalho.getText().toString());
                trabalhos.setSenha(SenhaTrabalho.getText().toString());

                salvarTrabalho(trabalhos);

            }
        });

        btnListar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),HomeActivity.class);
                startActivity(i);
            }
        });
    }

    private boolean salvarTrabalho(Trabalhos trabalhos) {
        try {
            firebase = ConfiguracaoFirebase.getFirebase().child("Trabalhos");
            firebase.child(trabalhos.getUsuario()).setValue(trabalhos);
            Toast.makeText(CadastroActivity.this, "Produto inserido com sucesso", Toast.LENGTH_LONG).show();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }
}
