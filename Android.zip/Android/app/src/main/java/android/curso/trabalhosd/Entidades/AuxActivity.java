package android.curso.trabalhosd.Entidades;

import android.curso.trabalhosd.R;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class AuxActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aux);
    }
}
