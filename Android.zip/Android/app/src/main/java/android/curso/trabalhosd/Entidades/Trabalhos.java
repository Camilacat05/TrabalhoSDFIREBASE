package android.curso.trabalhosd.Entidades;

public class Trabalhos {

    private String NomeTrabalho;
    private String NomeAutor;
    private String Linguagem;
    private String EnderecoGit;
    private String Usuario;
    private String Senha;



    public Trabalhos(){

    }

    public String getSenha() {
        return Senha;
    }

    public void setSenha(String senha) {
        Senha = senha;
    }

    public String getNomeTrabalho() {
        return NomeTrabalho;
    }

    public void setNomeTrabalho(String nomeTrabalho) {
        NomeTrabalho = nomeTrabalho;
    }

    public String getNomeAutor() {
        return NomeAutor;
    }

    public void setNomeAutor(String nomeAutor) {
        NomeAutor = nomeAutor;
    }

    public String getLinguagem() {
        return Linguagem;
    }

    public void setLinguagem(String linguagem) {
        Linguagem = linguagem;
    }

    public String getEnderecoGit() {
        return EnderecoGit;
    }

    public void setEnderecoGit(String enderecoGit) {
        EnderecoGit = enderecoGit;
    }

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String usuario) {
        Usuario = usuario;
    }
}
