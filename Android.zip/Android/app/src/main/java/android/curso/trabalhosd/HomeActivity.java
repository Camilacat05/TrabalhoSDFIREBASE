package android.curso.trabalhosd;

import android.content.DialogInterface;
import android.content.Intent;
import android.curso.trabalhosd.Adapter.TrabalhosAdapter;
import android.curso.trabalhosd.DAO.ConfiguracaoFirebase;
import android.curso.trabalhosd.Entidades.Trabalhos;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class HomeActivity extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<Trabalhos> adapter;
    private ArrayList<Trabalhos> trabalhos;
    private DatabaseReference firebase;
    private ValueEventListener valueEventListenerTrabalhos;
    private Trabalhos ExcluirTrabalho;
    private Button btnCadastrar2;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        trabalhos = new ArrayList<>();
        listView =  findViewById(R.id.listViewTrabalhos);
        adapter = new TrabalhosAdapter(this, trabalhos);
        listView.setAdapter(adapter);
        firebase = ConfiguracaoFirebase.getFirebase().child("Trabalhos");
        btnCadastrar2 = findViewById(R.id.btnCadastrar2);

        btnCadastrar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),CadastroActivity.class);
                startActivity(i);
            }
        });

        valueEventListenerTrabalhos = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                trabalhos.clear();

                for (DataSnapshot dados : dataSnapshot.getChildren()) {
                    Trabalhos TrabalhoNovo = dados.getValue(Trabalhos.class);

                    trabalhos.add(TrabalhoNovo);
                }

                adapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        };

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                ExcluirTrabalho = adapter.getItem(position);

                AlertDialog alertDialog = new AlertDialog.Builder(HomeActivity.this).create();
                alertDialog.setTitle("Escolha");
                alertDialog.setMessage("Informe o que deseja fazer");

                alertDialog.setButton(alertDialog.BUTTON_POSITIVE, "Alterar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Bundle b = new Bundle();
                        b.putString("user",ExcluirTrabalho.getUsuario());

                        Intent i = new Intent(getApplicationContext(),AlterarActivity.class);
                        i.putExtras(b);

                        startActivity(i);
                    }
                });

                alertDialog.setButton(alertDialog.BUTTON_NEGATIVE, "Excluir", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        firebase.child(ExcluirTrabalho.getUsuario()).removeValue();

                        Toast.makeText(getApplicationContext(),"Exclusão efetuada com sucesso!",Toast.LENGTH_SHORT).show();
                    }
                });
                alertDialog.show();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        firebase.addValueEventListener(valueEventListenerTrabalhos);
    }

    @Override
    protected void onStop() {
        super.onStop();
        firebase.removeEventListener(valueEventListenerTrabalhos);
    }
}
